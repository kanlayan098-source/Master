BUILDORIA Master Resource Pack v1
รวม Resource Pack สำหรับ:
- BuildoriaFood (อาหาร ผัก เมล็ด ต้นพืช เครื่องครัว)
- BuildoriaFurniture v10 (เฟอร์นิเจอร์ Home & Cafe Deluxe)

ใช้ไฟล์ ZIP นี้เป็น resource-pack เพียงตัวเดียวใน server.properties
ไม่ต้องแตกไฟล์ ZIP ก่อนใช้งานบนเซิร์ฟเวอร์
